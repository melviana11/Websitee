<!DOCTYPE html>
<html>
<body>
 
	<center>
 
		<h2>LAPORAN DATA KEHADIRAN</h2>
		
 
	</center>
 
	<?php 
	include 'koneksi.php';
	?>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="1%">No</th>
			<th>Id</th>
			<th>Nama</th>
			<th>Tanggal_Absen</th>
			<th>keterangan</th>
		</tr>
		<?php 
		$no = 1;
		$sql = mysqli_query($koneksi,"select * from data_kehadiran");
		while($data = mysqli_fetch_array($sql)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $data['id']; ?></td>
			<td><?php echo $data['Nama']; ?></td>
			<td><?php echo $data['tanggal_absen']; ?></td>
			<td><?php echo $data['keterangan']; ?></td>
		
		</tr>
		<?php 
		}
		?>
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>