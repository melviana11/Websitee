<!DOCTYPE html>
<html>

<head>
<title>login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <nav class="navbar navbar-expand-lg"  style = "background-color: #3876BF;; color: #fff;">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="beranda.php">Beranda</a>
        </li>
        <li class="nav-item">
		<a class="nav-link active" aria-current="page" href="index.php">pemain</a>
        </li>
		<li class="nav-item">
          <a class="nav-link active" aria-current="page" href="datakehadiran.php">kehadiran</a>
        </li>
		<li class="nav-item">
		<a class="nav-link active" aria-current="page" href="login.php">login</a>
    </li>
		<li class="nav-item">
		<a class="nav-link active" aria-current="page" href="logut.php"></a>
       
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
       
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" >
        <button class="btn btn-success" type="submit">Cari</button>
      </form>
    </div>
  </div>
</nav>

    <div class="row justify-content-center">
    <h1 class="text-center mt-5 mb-4">FORM LOGIN</h1>
        <div class="col-lg-6" style="border: 1px solid; padding: 30px;">
            <form method="post" action="login_aksi.php">
                <div>
                    <p class="mt-3 mb-1 fw-semibold">USERNAME :</p>
                    <input class="form-control" type="text" name="username">
                </div>
                <div>
                    <p class="mt-3 mb-1 fw-semibold">PASSWORD :</p>
                    <input class="form-control" type="password" name="password">
                </div>
                <?php
                session_start();

                if (isset($_SESSION['error'])) {
                    echo '<p class="text-danger text-center mt-4 mb-2">' . $_SESSION['error'] . '</p>';
                    unset($_SESSION['error']);
                }
                ?>
                <div class="text-center mt-4">
                    <button class="btn fw-semibold btn-primary me-2" style="padding: 5px 50px 5px 50px;" type="submit">LOGIN</button>
                </div>
            </form>
        </div>
    </div>
    </body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</html>