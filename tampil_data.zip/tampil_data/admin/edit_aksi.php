<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama = $_POST['Nama'];
$tanggal_absen = $_POST['tanggal_absen'];
$keterangan = $_POST['keterangan'];
 
// update data ke database
mysqli_query($koneksi,"UPDATE data_kehadiran SET Nama='$nama', tanggal_absen='$tanggal_absen', keterangan='$keterangan' where id='$id'");
 
// mengalihkan halaman kembali ke index.php
header("location:datakehadiran.php");
 
?>