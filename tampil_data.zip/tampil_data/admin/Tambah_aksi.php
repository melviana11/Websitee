<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$Nama = $_POST['Nama'];
$tanggal_absen = $_POST['tanggal_absen'];
$keterangan = $_POST['keterangan'];

 
// menginput data ke database
mysqli_query($koneksi,"INSERT INTO data_kehadiran VALUES('$id','$Nama','$tanggal_absen','$keterangan')");
 
// mengalihkan halaman kembali ke index.php
header("location:datakehadiran.php");
 
?>