<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$Nama = $_POST['Nama'];
$Tanggal_lahir = $_POST['Tanggal_lahir'];
$Kelamin = $_POST['Kelamin'];

 
// menginput data ke database
mysqli_query($koneksi,"insert into pemain values('$id','$Nama','$Tanggal_lahir','$Kelamin')");
 
// mengalihkan halaman kembali ke index.php
header("location:index.php");
 
?>