<!DOCTYPE html>
<html>
<head>
	<title>Tampilan Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<nav class="navbar navbar-expand-lg"  style = "background-color: #3876BF;; color: #fff;">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="beranda.php">Beranda</a>
        </li>
        <li class="nav-item">
		<a class="nav-link active" aria-current="page" href="index.php">pemain</a>
        </li>
		<li class="nav-item">
          <a class="nav-link active" aria-current="page" href="datakehadiran.php">kehadiran</a>
        </li>
		<li class="nav-item">
		<a class="nav-link active" aria-current="page" href="login.php"></a>
    </li>
		<li class="nav-item">
		<a class="nav-link active" aria-current="page" href="logut.php">log-ut</a>
       
          </a>
          <ul class="dropdown-menu"> 
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
       
        </li>
      </ul>
<div>
<form class="d-flex" role="search">

<!-- Button -->
    <input class="form-control me-2" type="search" name="cari" placeholder="Cari..." aria-label="Search" value="<?php echo isset($_GET['cari']) ? $_GET['cari'] : ''; ?>">
    <button class="btn btn-success" type="submit">Cari</button>

    <?php if(isset($_GET['cari'])): ?>
      <a href="index.php" class="btn btn-danger ml-2">X</a>
    <?php endif; ?>
  </form>
</div>
    </div>
  </div>
</nav>
</head>
<body>
 
	<h2 class = "text-center mt-5"> Tampilan Data Pemain</h2>
	<br/>
	<a href="tambah_pemain.php" class="btn btn-success"> TAMBAH DATA</a>
	<br/>
	<br/>
	<table class = "table table-bordered">
		<tr>    
			<th style = "background-color: #3876BF; color: #fff;"> NO</th>
			<th style = "background-color: #3876BF; color: #fff;">ID</th>
			<th style = "background-color: #3876BF; color: #fff;">Nama</th>
			<th style = "background-color: #3876BF; color: #fff;">Tanggal Lahir</th>
			<th style = "background-color: #3876BF; color: #fff;">kelamin</th>
            <th style = "background-color: #3876BF; color: #fff;">Opsi</th>
		</tr>
		
	<?php
	include 'koneksi.php';
		// Proses pencarian
    if(isset($_GET['cari'])){
      $cari = $_GET['cari'];
      $data = mysqli_query($koneksi, "SELECT * FROM pemain WHERE id LIKE '%$cari%' OR Nama LIKE '%$cari%' OR Tanggal_lahir LIKE '%$cari%' OR Kelamin LIKE '%$cari%'");
    } else {
      $data = mysqli_query($koneksi, "SELECT * FROM pemain");
    }

    $no = 1;
    while ($d = mysqli_fetch_array($data)) {
    ?>
			
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['id']; ?></td>
				<td><?php echo $d['Nama']; ?></td>
                <td><?php echo $d['Tanggal_lahir']; ?></td>
				<td><?php echo $d['Kelamin']; ?></td>
				<td>
					<a href="edit1.php?id=<?php echo $d['id']; ?>" onclick="return confirm('apakah anda yakin mau mengedit data ini ?');"class="btn btn-warning">EDIT</a>
					<a href="hapus.php?id=<?php echo $d['id']; ?>" onclick="return confirm('apakah anda yakin mau menghapus data ini ?');"  class="btn btn-danger">HAPUS</a>
			</tr>
			<?php 
		}
		?>
	</table>
	
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>