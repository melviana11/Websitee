
<html>
<head>
	<title>EDIT DATA</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <nav class="navbar navbar-expand-lg" style = "background-color: #3876BF;; color: #fff;">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">pemain</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="datakehadiran.php">Kehadiran</a>
        </li>
        <li class="nav-item">
		<a class="nav-link active" aria-current="page" href="Tambah.php"></a>
        </li>
        <li class="nav-item">
		<a class="nav-link active" aria-current="page" href="Tambah_pemain.php"></a>
        </li>
        <li class="nav-item">
        </li>
      </ul>
    </div>
  </div>
</nav>
</head>
<body class="bg-primary-subtle ">
 <div>
	<br/>
	<br/>
	<br/>
	<h3 class="Text-center mt-5">EDIT DATA PEMAIN</h3>
 
	<?php
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from pemain where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="edit_aksi2.php">
			<table>
				<tr>			
					<td>ID</td>
					<td>
						<input type="text" name="id" value="<?php echo $d['id']; ?>">
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
					</td>
				</tr>
				<tr>
					<td>Nama</td>
					<td><input type="text" name="Nama" value="<?php echo $d['Nama']; ?>"></td>
				</tr>
				<tr>
					<td>Tanggal_Lahir</td>
					<td><input type="text" name="Tanggal_lahir" value="<?php echo $d['Tanggal_lahir']; ?>"></td>
				</tr>
                <tr>
					<td>Kelamin</td>
					<td><input type="text" name="kelamin" value="<?php echo $d['Kelamin']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
 </div>
</body>
</html>