<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama = $_POST['Nama'];
$Tanggal_lahir = $_POST['Tanggal_lahir'];
$Kelamin = $_POST['kelamin'];
 
// update data ke database
mysqli_query($koneksi,"UPDATE pemain SET Nama='$nama', Tanggal_lahir='$Tanggal_lahir', Kelamin='$Kelamin' where id='$id'");
 
// mengalihkan halaman kembali ke index.php
header("location:index.php");
 
?>